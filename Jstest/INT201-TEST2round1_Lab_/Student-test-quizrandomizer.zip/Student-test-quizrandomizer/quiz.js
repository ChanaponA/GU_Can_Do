//Write your student id, firstname, and lastname in a single line comment before starting your program
//students who do not put this comment will get 50% taken off their score.
//ID:       Name:

import { quizQuestions, getRandomQuiz } from "./quizQuestions.js";

let randomQuiz;

function init() {
//insert your code here
}

function generateQuiz() {
//insert your code here
}

function clearQuiz() {
//insert your code here
}

function checkAnswer(e) {
//insert your code here
}

init();
